rootProject.name="InventoryApp"
include(":app")